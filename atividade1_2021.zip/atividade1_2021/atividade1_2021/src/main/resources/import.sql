
insert into cidade (nome) values ('São Paulo');
insert into cidade (nome) values ('Francisco Beltrão');
insert into cidade (nome) values ('Pato Branco');


insert into autor (nome) values ('Eduardo Felipe Zambom Santana');
insert into autor (nome) values ('Hugo Kotsubo');
insert into autor (nome) values ('Monteiro Lobato');
insert into autor (nome) values ('Cecilia Meireles');

insert into editora (nome) values ('Campus Elsevier');
insert into editora (nome) values ('Sextante');
insert into editora (nome) values ('Pearson');
insert into editora (nome) values ('Panini');

insert into genero (descricao) values ('Java');
insert into genero (descricao) values ('C#');
insert into genero (descricao) values ('Kotlin');
insert into genero (descricao) values ('Javascript');

insert into livro (titulo, editora_id, genero_id, autor_id, ano, isbn, cidade_id, preco, url_imagem, conteudo) values ('Back-end Java', 1, 1, 1, 2020, '978-65-86110-61-6', 1, 109.90, 'https://cdn.shopify.com/s/files/1/0155/7645/products/cover_f3840de2-4ac0-4f3e-a8a7-9de0d411fe2a_large.jpg?v=1616122279',' <p align="justify">A arquitetura dos sistemas de software vem sofrendo diversas revoluções nos últimos anos, desde os grandes monólitos até os microsserviços. Atualmente, para a plataforma Java, o framework mais utilizado para desenvolver microsserviços é o Spring Boot, que facilita a configuração e o uso de bibliotecas necessárias. Mas para executar uma aplicação inteira, tanto em um ambiente local quanto de produção, é necessário rodar e configurar todos os serviços e permitir que eles se comuniquem. Hoje é essencial que a pessoa desenvolvedora back-end conheça, além da linguagem de programação, algumas dessas ferramentas para a execução da aplicação em um ambiente de produção. É esse o objetivo dos contêineres Docker e do Kubernetes.</p> <p align="justify">Neste livro, Eduardo Zambom Santana vai passar por todo o back-end de uma aplicação Java. Você vai desenvolver uma aplicação de exemplo com o Spring Boot formada por três microsserviços inicialmente independentes, com as responsabilidades de gerenciar usuários, produtos e compras. Em seguida, você trabalhará na comunicação entre seus microsserviços, criando imagens Docker para eles e, por fim, executando a aplicação em um cluster Kubernetes.</p>');

insert into livro (titulo, editora_id, genero_id, autor_id, ano, isbn, cidade_id, preco, url_imagem, conteudo) values ('Datas e horas', 4, 1, 2, 2019, '978-85-7254-005-6', 2, 25.00, 'https://cdn.shopify.com/s/files/1/0155/7645/products/p_1fe74e94-82e9-413f-9d3d-c2d473da9861_large.jpg?v=1553198246', '<p align="justify"> A arquitetura dos sistemas de software vem sofrendo diversas revoluções nos últimos anos, desde os grandes monólitos até os microsserviços. Atualmente, para a plataforma Java, o framework mais utilizado para desenvolver microsserviços é o Spring Boot, que facilita a configuração e o uso de bibliotecas necessárias. Mas para executar uma aplicação inteira, tanto em um ambiente local quanto de produção, é necessário rodar e configurar todos os serviços e permitir que eles se comuniquem. Hoje é essencial que a pessoa desenvolvedora back-end conheça, além da linguagem de programação, algumas dessas ferramentas para a execução da aplicação em um ambiente de produção. É esse o objetivo dos contêineres Docker e do Kubernetes.</p> <p align="justify">Neste livro, Eduardo Zambom Santana vai passar por todo o back-end de uma aplicação Java. Você vai desenvolver uma aplicação de exemplo com o Spring Boot formada por três microsserviços inicialmente independentes, com as responsabilidades de gerenciar usuários, produtos e compras. Em seguida, você trabalhará na comunicação entre seus microsserviços, criando imagens Docker para eles e, por fim, executando a aplicação em um cluster Kubernetes.</p>');

insert into livro (titulo, editora_id, genero_id, autor_id, ano, isbn, cidade_id, preco, url_imagem, conteudo) values ('Produtividade em C#', 1, 2, 3, 2020, '978-65-86110-70-8', 1, 47.50, 'https://cdn.shopify.com/s/files/1/0155/7645/products/p_291a0bf4-f14f-4fc3-b170-85bedd66e210_large.jpg?v=1621390089', '<p align="justify"> A arquitetura dos sistemas de software vem sofrendo diversas revoluções nos últimos anos, desde os grandes monólitos até os microsserviços. Atualmente, para a plataforma Java, o framework mais utilizado para desenvolver microsserviços é o Spring Boot, que facilita a configuração e o uso de bibliotecas necessárias. Mas para executar uma aplicação inteira, tanto em um ambiente local quanto de produção, é necessário rodar e configurar todos os serviços e permitir que eles se comuniquem. Hoje é essencial que a pessoa desenvolvedora back-end conheça, além da linguagem de programação, algumas dessas ferramentas para a execução da aplicação em um ambiente de produção. É esse o objetivo dos contêineres Docker e do Kubernetes.</p> <p align="justify">Neste livro, Eduardo Zambom Santana vai passar por todo o back-end de uma aplicação Java. Você vai desenvolver uma aplicação de exemplo com o Spring Boot formada por três microsserviços inicialmente independentes, com as responsabilidades de gerenciar usuários, produtos e compras. Em seguida, você trabalhará na comunicação entre seus microsserviços, criando imagens Docker para eles e, por fim, executando a aplicação em um cluster Kubernetes.</p>');

insert into livro (titulo, editora_id, genero_id, autor_id, ano, isbn, cidade_id, preco, url_imagem, conteudo) values ('Kotlin com Android', 2, 3, 4, 2021, '978-65-86110-61-6', 3, 60.00, 'https://cdn.shopify.com/s/files/1/0155/7645/products/p_4d784e4f-769e-4f00-82d9-c1c81628055a_large.jpg?v=1532117965', '<p align="justify"> A arquitetura dos sistemas de software vem sofrendo diversas revoluções nos últimos anos, desde os grandes monólitos até os microsserviços. Atualmente, para a plataforma Java, o framework mais utilizado para desenvolver microsserviços é o Spring Boot, que facilita a configuração e o uso de bibliotecas necessárias. Mas para executar uma aplicação inteira, tanto em um ambiente local quanto de produção, é necessário rodar e configurar todos os serviços e permitir que eles se comuniquem. Hoje é essencial que a pessoa desenvolvedora back-end conheça, além da linguagem de programação, algumas dessas ferramentas para a execução da aplicação em um ambiente de produção. É esse o objetivo dos contêineres Docker e do Kubernetes.</p> <p align="justify">Neste livro, Eduardo Zambom Santana vai passar por todo o back-end de uma aplicação Java. Você vai desenvolver uma aplicação de exemplo com o Spring Boot formada por três microsserviços inicialmente independentes, com as responsabilidades de gerenciar usuários, produtos e compras. Em seguida, você trabalhará na comunicação entre seus microsserviços, criando imagens Docker para eles e, por fim, executando a aplicação em um cluster Kubernetes.</p>');

insert into permissao (nome) values('ROLE_ADMIN');
insert into permissao (nome) values('ROLE_USER');

insert into endereco(endereco, numero, bairro, complemento, cidade, estado, cep) values('Rua General Osório', '60', 'centro', 'sala 01', 'São João', 'PR', '85570-000');

insert into usuario(nome, username, password, email, celular) values ('Administrador', 'admin','$2a$10$/sjlbpUaUHmPMdX3Ixf8lOQursoAh.OcL6cG4vSeIIu/m/MnDNOJO', 'valdineibucmaier@gmail.com', '46988144777');

insert into usuario_endereco(usuario_id, endereco_id)values(1, 1);

insert into usuario_permissoes(usuario_id, permissoes_id) values (1, 1);
insert into usuario_permissoes(usuario_id, permissoes_id) values (1, 2);