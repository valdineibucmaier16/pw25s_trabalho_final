

function remover(id){
	
	
var compraItens = [];
	
	if(localStorage.getItem("carrinho")){
		compraItens = JSON.parse(localStorage.getItem("carrinho"));
	}
	
	var indexItemRemover = -1;
	
	indexItemRemover = compraItens.findIndex((item) => item.id === id.toString());
	
	if(indexItemRemover >=0){
		compraItens.splice(indexItemRemover,1);
	}
	
	localStorage.setItem("carrinho", JSON.stringify(compraItens));
	
	if(compraItens.length == 0){
		localStorage.removeItem("carrinho");
	}
	
	location.reload()
	
	
}



// --------------------------------------------checkout----------------------------------

function carregaCheckout(){
	
	// carregando itens do carrinho
	
	var cardCarrinho = document.getElementById("cardCarrinho");
	var totalItensCartNav = document.getElementById("totalItens");
	var tituloProdutosPedido = document.getElementById("tituloProdutosPedido");
	var tituloEnderecoEntregaPedido = document.getElementById("tituloEnderecoEntregaPedido");
	var cardEnderecoEntrega = document.getElementById("cardEnderecoEntrega");
	var tituloContatoEntregaPedido = document.getElementById("tituloContatoEntregaPedido");
	var cardContatoEntrega = document.getElementById("cardContatoEntrega");
	
	var tituloMeioPagamentoPedido = document.getElementById("tituloMeioPagamentoPedido");
	var cardMeioPagamento = document.getElementById("cardMeioPagamento");
	var btnFinalizarPedido = document.getElementById("btnFinalizarPedido");
	
var compraItens = [];
	
	if(localStorage.getItem("carrinho")){
		compraItens = JSON.parse(localStorage.getItem("carrinho"));
		
		cardCarrinho.removeAttribute("hidden");
		tituloProdutosPedido.removeAttribute("hidden");
		tituloEnderecoEntregaPedido.removeAttribute("hidden");
		cardEnderecoEntrega.removeAttribute("hidden");
		tituloContatoEntregaPedido.removeAttribute("hidden");
		cardContatoEntrega.removeAttribute("hidden");
		tituloMeioPagamentoPedido.removeAttribute("hidden");
		cardMeioPagamento.removeAttribute("hidden");
		btnFinalizarPedido.removeAttribute("hidden");
		
	}
	else{
		if(compraItens.length == 0){
			var msgVazio = "Você ainda não escolheu nenhum livro.";
			document.getElementById("tituloPaginaCarrinho").textContent=msgVazio;
			document.getElementById("subtituloPaginaCarrinho").textContent="Dê uma olhada nos livros disponíveis";
			
		}
	}
	
	
	var divCarrinho = document.querySelector('#divCarrinho');
	
	var totalPedido = 0;
	var quantidadeTotalItens = 0;
	var linha = "";
	compraItens.forEach(function(item){

		quantidadeTotalItens += parseInt(item.quantidade);
		var preco = (item.preco).replace(",",".");
		
		var totalItem = (parseFloat(preco)*item.quantidade).toFixed(2);
		
		totalPedido = totalPedido+parseFloat(totalItem);
		
			linhaItem = "<div class='row'>" +
			
			"<div class='row col-md-6'>"+
			"<div class='col-md-3'><img class='img-thumbnail'src='"+item.urlImagem+"'/></div>"+
				"<div class='col-md-8'><span>"+item.titulo+"</span></div>"+
				
			"</div>"+
			
			"<div class='col-md-2 text-center ml-1'>"+
				"R$<span>"+item.preco+"</span>"+
			"</div>"+
			"<div class='col-md-2 text-center' >"+
				"<span id='spanCarrinhoCheckout'"+item.id+">"+item.quantidade+"</span>"+
			"</div>"+
			"<div class='col-md-2'>"+
				
				"<span class='col-6'>"+"R$"+totalItem.replace(".",",")+"</span>"+
					
			"</div>"+
		"</div>"+	
		  
	"</div>"
			linha+= linhaItem;
		
		
	});
	
	var linhaSubTotal = "<div class='row col-12 text-center pb-4'>"+
	"<div class='col-8'><b>Subtotal</b></div>"+
	"<div class='col-2'><b>R$</b><span><b>"+totalPedido.toFixed(2)+"</b></span></div>"+
	"</div>"
	
	var valorEntrega = "Grátis"
	var diasUteisEntrega = 10
	var linhaEntrega = "<div class='row col-12 text-center pb-4'>"+
	"<div class='col-8'><b>Entrega em até "+diasUteisEntrega+" dias úteis</b></div>"+
	"<div class='col-2'><span><b>"+valorEntrega+"</b></span></div>"+
	"</div>"
	
	var linhaTotal = "<div class='row col-12 text-center'>"+
	"<div class='col-8'><b>Total do Pedido</b></div>"+
	"<div class='col-2'><b>R$</b><span><b>"+totalPedido.toFixed(2)+"</b></span></div>"+
	"<div class='col-12 text-center' id='btnVoltarCarrinho'><a class='btn btn-warning mt-5'  href='/carrinho'><b>Voltar ao carrinho</b></a></div>"+
	"</div>"
	
	linha+= linhaSubTotal;
	linha+= linhaEntrega;
	linha+= linhaTotal;
	
	divCarrinho.innerHTML = linha;
	
	document.getElementById("totalPreco").textContent= "R$"+ totalPedido.toFixed(2).replace(".",",");
	document.getElementById("totalItens").textContent = quantidadeTotalItens;
	
	
	
	
}


// ----------------------------------------------------------------------------------------------
	

function salvarCompra(){
	  
    const url = "/compra-dto";
    let req = new XMLHttpRequest();
    req.open("POST", url, true);
    req.setRequestHeader('Content-type', 'application/json; charset=utf-8');

	var compraItens = [];
	
	var compraProdutos = [];
	
	if(localStorage.getItem("carrinho")){
		compraItens = JSON.parse(localStorage.getItem("carrinho"));
		
	}
	
	
	compraItens.forEach(function(item){
		
		let compraLivro = new Object();
		
		compraLivro.produtoId = item.id;
		compraLivro.quantidade = item.quantidade;
		compraLivro.valor = (item.preco).replace(",",".");
		
		compraProdutos.push(compraLivro);
	});
    
    
    var compra = new Object();
	compra.compraLivros = compraProdutos;
	
	var meiosPagamento = document.getElementsByName("meio_pagamento");
	
	var algumRadioSelecionado = false;
	
	for(var i= 0; i < meiosPagamento.length; i++){
		if(meiosPagamento[i].checked){
			
			
				compra.meioPagamento = meiosPagamento[i].value;
				algumRadioSelecionado = true;
		}
		
		
	}
	
	if(!algumRadioSelecionado){
		
			swal("Por favor selecione um meio de pagamento.");
			return
		
	}
	
	var enderecoEntrega = document.getElementById("enderecoEntrega").innerText;
	 
	compra.enderecoEntrega = enderecoEntrega
	
	
	
    let json = JSON.stringify(compra);
    req.onload = function () {
        if (req.readyState == 4 && req.status == "200") {
        	
        	
		       
        	/*
			 * swal({ title: "Sucesso!", text: "Sua compra foi realizada!",
			 * type: "success" }).then( function() { window.location =
			 * '/compra-dto'; });
			 */ 
        	
        	localStorage.removeItem("carrinho");
        	
        	
        	 swal('Sucesso!', 'Sua compra foi realizada', 'success').then(function(){
        		 window.location = '/compra-dto';
        	 });
			         	
		      
			
        } else {
            console.error('Falha ao salvar registro');
            swal('Algo deu errado!', 'Falha ao salvar sua compra, tente novamente!', 'error');
            
        }
    }
    req.send(json);
    
   return false
}


// -------------------------------------------------------
function funcao1()
{
	// testes

}


// --------------------------------------------------------
function adicionaAoCarrinhoQuantidade(idProduto){
	
	
	var inputCarrinho = document.getElementById("inputCarrinho"+idProduto.toString())
	
	var quantidade = inputCarrinho.value;
	
	var compraItens = [];
		
		if(localStorage.getItem("carrinho")){
			compraItens = JSON.parse(localStorage.getItem("carrinho"));
		}
		
		
		
		var item = compraItens.find((item) => item.id === idProduto.toString());
		
		item.quantidade = quantidade ;
		
		
		localStorage.setItem("carrinho", JSON.stringify(compraItens));
		
		if(compraItens.length == 0){
			localStorage.removeItem("carrinho");
		}
		
		location.reload()
	
}

function carregaCarrinho(){
	
	var cardCarrinho = document.getElementById("cardCarrinho");
	var totalItensCartNav = document.getElementById("totalItens");
	
var compraItens = [];
	
	if(localStorage.getItem("carrinho")){
		compraItens = JSON.parse(localStorage.getItem("carrinho"));
		cardCarrinho.removeAttribute("hidden");
	}
	else{
		if(compraItens.length == 0){
			var msgVazio = "Seu carrinho de compras ainda está vazio.";
			document.getElementById("tituloPaginaCarrinho").textContent=msgVazio;
			document.getElementById("subtituloPaginaCarrinho").textContent="Dê uma olhada nos livros disponíveis";
			
		}
	}
	
		
	var divCarrinho = document.querySelector('#divCarrinho');
	
	
	var totalPedido = 0;
	var quantidadeTotalItens = 0;
	var linha = "";
	compraItens.forEach(function(item){

		quantidadeTotalItens += parseInt(item.quantidade);
		var preco = (item.preco).replace(",",".");
		
		var totalItem = (parseFloat(preco)*item.quantidade).toFixed(2);
		
		totalPedido = totalPedido+parseFloat(totalItem);
		
		
			linhaItem = "<div class='row'>" +
			
			"<div class='row col-md-6'>"+
			"<div class='col-md-4'><img class='img-thumbnail'src='"+item.urlImagem+"'/></div>"+
				"<div class='col-md-8'><span>"+item.titulo+"</span></div>"+
				
			"</div>"+
			
			"<div class='col-md-2 text-center ml-1'>"+
				"R$<span>"+item.preco+"</span>"+
			"</div>"+
			"<div class='col-md-2 text-center' >"+
				"<input id='inputCarrinho"+item.id+"'type='number'  min='1' value='"+item.quantidade+"'onchange='adicionaAoCarrinhoQuantidade("+item.id+")' />"+
			"</div>"+
			"<div class='col-md-2'>"+
				
				"<span class='col-6'>"+"R$"+totalItem.replace(".",",")+"</span>"+
				
				"<div class='btn col-6'id='lixeira' onclick='remover("+item.id+")'>"+
				"<svg xmlns='http://www.w3.org/2000/svg' width='20' height='20' fill='currentColor' class='bi bi-trash' viewBox='0 0 16 16'>"+
				  "<path d='M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z'/>"+
				  "<path fill-rule='evenodd' d='M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z'/>"+
				"</svg>"+
				"</div>"+
				
				
				
			"</div>"+
		"</div>"+	
		  
	"</div>"
			linha+= linhaItem;
		
		
	});
	
	
	var linhaSubTotal = "<div class='row col-12 text-center pb-4'>"+
	"<div class='col-8'><b>Subtotal</b></div>"+
	"<div class='col-2'><b>R$</b><span><b>"+totalPedido.toFixed(2)+"</b></span></div>"+
	"</div>"
	
	var valorEntrega = "Grátis"
	var diasUteisEntrega = 10
	var linhaEntrega = "<div class='row col-12 text-center pb-4'>"+
	"<div class='col-8'><b>Entrega em até "+diasUteisEntrega+" dias úteis</b></div>"+
	"<div class='col-2'><span><b>"+valorEntrega+"</b></span></div>"+
	"</div>"
	
	var linhaTotal = "<div class='row col-12 text-center'>"+
	"<div class='col-8'><b>Total do Pedido</b></div>"+
	"<div class='col-2'><b>R$</b><span><b>"+totalPedido.toFixed(2)+"</b></span></div>"+
	"<div class='col-2' ><a class='btn btn-primary mt-5' id='btnFinalizarPedido' href='/carrinho/checkout'><b>Finalizar Pedido</b></a></div>"+
	"</div>"
	
	linha+= linhaSubTotal;
	linha+= linhaEntrega;
	linha+= linhaTotal;
	
	divCarrinho.innerHTML = linha;
	
	document.getElementById("totalPreco").textContent= "R$"+ totalPedido.toFixed(2).replace(".",",");
	document.getElementById("totalItens").textContent = quantidadeTotalItens;
	
	var produtoLixeira = document.getElementById("lixeira");
	
	var texto = produtoLixeira.value;
	
	console.log(texto);
	
}


// ---------------------------------------------------------------

function adicionaAoCarrinho()
{
	
	
	var idLivro = document.getElementById("idLivro").textContent;
	var preco = document.getElementById("preco").textContent;
	var tituloLivro = document.getElementById("titulo").textContent;
	var urlImagem = document.getElementById("urlImagem").src;
	
	
	
	var compraItens = [];
	
	if(localStorage.getItem("carrinho")){
		compraItens = JSON.parse(localStorage.getItem("carrinho"));
	}
	
	var compraItem = {id: idLivro, preco: preco, titulo: tituloLivro, urlImagem: urlImagem, quantidade: 1};
	
	var existeItem = false
	compraItens.forEach(function(compraItem){
		
		if(idLivro == compraItem.id){
			existeItem = true;
			compraItem.quantidade++;
		}
		
	});
	
	if(!existeItem){
		compraItens.push(compraItem);
		localStorage.setItem("carrinho", JSON.stringify(compraItens));
	}
	else{
		localStorage.setItem("carrinho", JSON.stringify(compraItens));
	}
		
	window.location.href = "/carrinho";
	
	

}

// -----------------------------------------------------------------------------

function carregaCarrinhoNav(){
	
	
	
	
var compraItens = [];
	
	if(localStorage.getItem("carrinho")){
		compraItens = JSON.parse(localStorage.getItem("carrinho"));
		
	}
	else{
		return
	}
	
	
	var totalPedido = 0;
	var quantidadeTotalItens = 0;
	var linha = "";
	compraItens.forEach(function(item){
		
		
		quantidadeTotalItens += parseInt(item.quantidade);
		var preco = (item.preco).replace(",",".");
		
		var totalItem = (parseFloat(preco)*item.quantidade).toFixed(2);
		
		totalPedido = totalPedido+parseFloat(totalItem);
			
	});
	
	
	
	document.getElementById("totalPreco").textContent= "R$"+ totalPedido.toFixed(2).replace(".",",");
	
	document.getElementById("totalItens").textContent = quantidadeTotalItens;
	
	
	
}



