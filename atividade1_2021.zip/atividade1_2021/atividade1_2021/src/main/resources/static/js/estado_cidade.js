
function buscaCep2() {
	let inputCep = document.querySelector('input\[name=cep\]');
	let cep = inputCep.value.replace('-', '');
	let url = 'http://viacep.com.br/ws/' + cep + '/json';
	let xhr = new XMLHttpRequest();
	xhr.open('GET', url, true);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status = 200)
				preencheCampos(JSON.parse(xhr.responseText));
		}
	}
	xhr.send();
}

function buscaCep() {
	let inputCep = document.querySelector('input\[name=cep\]');
	let cep = inputCep.value.replace('-', '');

	const url = 'http://viacep.com.br/ws/' + cep + '/json';
	let req = new XMLHttpRequest();
	req.open('GET', url, true);

	req.onload = function() {
		let data = JSON.parse(req.responseText);
		if (req.readyState == 4 && req.status == "200") {

			preencheCampos(JSON.parse(req.responseText))
		} else {
			console.error('Falha ao carregar dados!');
		}
	}
	req.send(null);
}

function preencheCampos(json) {
	document.querySelector("#cep").value = json.cep;
	document.querySelector("#endereco").value = json.logradouro;
	document.querySelector("#bairro").value = json.bairro;
	document.querySelector("#complemento").value = json.complemento;
	document.querySelector("#cidade").value = json.localidade;
	document.querySelector("#estado").value = json.uf;
}
