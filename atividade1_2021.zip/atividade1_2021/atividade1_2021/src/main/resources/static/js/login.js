$(document).ready(function() {

});

var carrinhoNav = document.getElementById("carrinhoImagem");
carrinhoNav.innerHTML = ""

function verificaSenhasIguais(campoConfirmacaoSenha) {

	if (campoConfirmacaoSenha.value != $("#password").val()) {
		campoConfirmacaoSenha
				.setCustomValidity("Senhas digitadas não conferem.");
	} else {
		campoConfirmacaoSenha.setCustomValidity("");
	}
}