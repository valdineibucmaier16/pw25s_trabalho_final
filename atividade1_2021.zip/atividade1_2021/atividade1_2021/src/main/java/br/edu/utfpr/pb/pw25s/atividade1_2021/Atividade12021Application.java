package br.edu.utfpr.pb.pw25s.atividade1_2021;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Atividade12021Application {

	public static void main(String[] args) {
		SpringApplication.run(Atividade12021Application.class, args);
	}

}
