package br.edu.utfpr.pb.pw25s.atividade1_2021.service;

import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Usuario;
import br.edu.utfpr.pb.pw25s.atividade1_2021.service.impl.UsuarioNotFoundException;

public interface UsuarioService extends CrudService<Usuario, Long> {

	public void updateResetPasswordToken(String token, String email) throws UsuarioNotFoundException;

	public Usuario get(String resetPasswordToken);

	public void updatePassword(Usuario usuario, String newPassword);
}
