package br.edu.utfpr.pb.pw25s.atividade1_2021.service;

import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Genero;
import br.edu.utfpr.pb.pw25s.atividade1_2021.service.CrudService;

public interface GeneroService extends CrudService<Genero, Long> {

}
