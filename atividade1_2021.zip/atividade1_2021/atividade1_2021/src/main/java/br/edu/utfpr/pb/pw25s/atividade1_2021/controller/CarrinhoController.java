package br.edu.utfpr.pb.pw25s.atividade1_2021.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Genero;
import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Usuario;
import br.edu.utfpr.pb.pw25s.atividade1_2021.repository.GeneroRepository;

@Controller
@RequestMapping("carrinho")
public class CarrinhoController {

	@Autowired
	private GeneroRepository generoRepository;

	@GetMapping
	public String carrinho(Model model) {

		List<Genero> generos = generoRepository.findAll();
		model.addAttribute("generos", generos);
		String msg = "Seu carrinho!";
		model.addAttribute("mensagemLivros", msg);
		return "carrinho";
	}

	@GetMapping(value = { "checkout" })
	public String checkout(Principal principal, Model model) {
		Object obj = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		if (obj instanceof Usuario) {
			Usuario usuario = (Usuario) obj;
			model.addAttribute("usuarioLogado", usuario);
		}

		return "checkout";
	}
}
