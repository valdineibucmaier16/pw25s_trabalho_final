package br.edu.utfpr.pb.pw25s.atividade1_2021.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Genero;
import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Livro;
import br.edu.utfpr.pb.pw25s.atividade1_2021.service.GeneroService;
import br.edu.utfpr.pb.pw25s.atividade1_2021.service.LivroService;

@Controller
public class HomeController {

	@Autowired
	private LivroService livroService;
	@Autowired
	private GeneroService generoService;

	/*
	 * @Autowired private LivroRepository repository;
	 * 
	 * @Autowired private GeneroRepository generoRepository;
	 * 
	 * @GetMapping(value = {"/", "home"}) public String home(Model model) {
	 * List<Livro> livros = repository.findAll(); model.addAttribute("livros",
	 * livros); List<Genero> generos = generoRepository.findAll();
	 * model.addAttribute("generos", generos); String msg = "";
	 * model.addAttribute("mensagemLivros", msg); return "home"; }
	 */

	@GetMapping(value = { "/", "home" })
	public String home(Model model) {

		List<Livro> livros = livroService.findAll();
		model.addAttribute("livros", livros);
		List<Genero> generos = generoService.findAll();
		model.addAttribute("generos", generos);
		String msg = "";
		model.addAttribute("mensagemLivros", msg);
		return "home";

	}
}
