package br.edu.utfpr.pb.pw25s.atividade1_2021.model;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Embeddable
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(of = { "compra", "livro" })
public class CompraLivroPK implements Serializable {
	private static final long serialVersionUID = 1L;

	@Getter
	@Setter
	@ManyToOne
	@JoinColumn(name = "compra_id", referencedColumnName = "id")
	private Compra compra;

	@Getter
	@Setter
	@ManyToOne
	@JoinColumn(name = "livro_id", referencedColumnName = "id")
	private Livro livro;

}
