package br.edu.utfpr.pb.pw25s.atividade1_2021.service;

import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Editora;
import br.edu.utfpr.pb.pw25s.atividade1_2021.service.CrudService;

public interface EditoraService extends CrudService<Editora, Long> {

}
