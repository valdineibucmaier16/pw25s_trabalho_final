package br.edu.utfpr.pb.pw25s.atividade1_2021.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Editora;
import br.edu.utfpr.pb.pw25s.atividade1_2021.repository.EditoraRepository;
import br.edu.utfpr.pb.pw25s.atividade1_2021.service.EditoraService;

@Service
public class EditoraServiceImpl extends CrudServiceImpl<Editora, Long> implements EditoraService {

	@Autowired
	private EditoraRepository editoraRepository;

	@Override
	protected JpaRepository<Editora, Long> getRepository() {
		return editoraRepository;
	}

}
