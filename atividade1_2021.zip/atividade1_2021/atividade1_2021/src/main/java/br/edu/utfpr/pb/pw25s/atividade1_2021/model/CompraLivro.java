package br.edu.utfpr.pb.pw25s.atividade1_2021.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
public class CompraLivro implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private CompraLivroPK id;

	@Column(nullable = false)
	private Integer quantidade;

	@Column(nullable = false)
	private Double valor;

}
