package br.edu.utfpr.pb.pw25s.atividade1_2021.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
public class Endereco implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotBlank
	@Column(length = 50, nullable = false)
	private String endereco;

	@NotBlank
	@Column(length = 10, nullable = false)
	private String numero;

	@NotBlank
	@Column(length = 50, nullable = false)
	private String bairro;

	@Column(length = 50)
	private String complemento;

	@NotBlank
	@Column(length = 50, nullable = false)
	private String cidade;

	@NotBlank
	@Column(length = 50, nullable = false)
	private String estado;

	@NotBlank
	@Column(length = 50, nullable = false)
	private String cep;

	@Override
	public String toString() {

		if (!complemento.isBlank()) {
			return endereco.toString().toUpperCase() + ", " + numero + ", " + complemento.toUpperCase() + ", "
					+ cidade.toUpperCase() + ", " + estado + ", " + "CEP " + cep;
		} else {
			return endereco.toString().toUpperCase() + ", " + numero + ", " + cidade.toUpperCase() + ", " + estado
					+ ", " + "CEP " + cep;

		}

	}

}
