package br.edu.utfpr.pb.pw25s.atividade1_2021.controller;

import java.io.UnsupportedEncodingException;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.mail.javamail.JavaMailSender;

import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Usuario;
import br.edu.utfpr.pb.pw25s.atividade1_2021.service.UsuarioService;
import br.edu.utfpr.pb.pw25s.atividade1_2021.service.impl.UsuarioNotFoundException;

@Controller
public class EsqueciPasswordController {

	@Autowired
	private UsuarioService usuarioService;

	@Autowired
	private JavaMailSender mailSender;

	@GetMapping(value = { "esqueci_password" })
	public String mostrarEsqueciSenhaForm(Model model) {

		return "form_esqueci_password";
	}

	@PostMapping("esqueci_password")
	public String processarEsqueciSenhaForm(HttpServletRequest requisicao, Model model) {

		String email = requisicao.getParameter("email");

		String stringAleatoria = "";
		String caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		for (var i = 0; i < 45; i++) {
			stringAleatoria += caracteres.charAt((int) Math.floor(Math.random() * caracteres.length()));
		}

		String token = stringAleatoria;

		try {
			usuarioService.updateResetPasswordToken(token, email);
			// gera link reset

			String siteURL = requisicao.getRequestURL().toString();

			String resetPasswordLink = siteURL.replace(requisicao.getServletPath(), "") + "/reset_password?token="
					+ token;

			// envia email

			sendEmail(email, resetPasswordLink);

			model.addAttribute("sucesso", "Email enviado com sucesso.");

		} catch (UsuarioNotFoundException e) {
			model.addAttribute("erro", e.getMessage());
		} catch (UnsupportedEncodingException | MessagingException e) {

			model.addAttribute("erro", "Falha durante envio do email.");
		}

		return "form_esqueci_password";

	}

	@GetMapping(value = { "reset_password" })
	public String resetPassword(@Param(value = "token") String token, Model model) {

		Usuario usuario = usuarioService.get(token);

		if (usuario == null) {
			model.addAttribute("message", "Token inválido");
			return "reset_password";
		}

		model.addAttribute("token", token);
		return "reset_password";
	}

	@PostMapping("reset_password")
	public String processaResetPassword(HttpServletRequest requisicao, Model model) {
		String token = requisicao.getParameter("token");
		String password = requisicao.getParameter("password");

		Usuario usuario = usuarioService.get(token);

		if (usuario == null) {
			model.addAttribute("message", "Token inválido");
			return "reset_password";
		} else {

			usuarioService.updatePassword(usuario, password);
			model.addAttribute("message", "Senha alterada com sucesso!");
			return "login";

		}
	}

	private void sendEmail(String email, String resetPasswordLink)
			throws UnsupportedEncodingException, MessagingException {
		MimeMessage message = mailSender.createMimeMessage();

		MimeMessageHelper helper = new MimeMessageHelper(message);

		helper.setFrom("valdineibucmaier@gmail.com", "Suporte Livraria do Código");
		helper.setTo(email);

		String subject = "Segue link para alterar sua senha";
		String content = "<p>Olá,</p>"
				+ "<p>Você solicitou resetar sua senha na Livraria do Código, clique no link a seguir:</p>"
				+ "<p><a href=\"" + resetPasswordLink + "\">Alterar minha senha</a></p>"
				+ "<p>Desconsidere esse email se você não deseja resetar sua senha.</p>";

		helper.setSubject(subject);
		helper.setText(content, true);

		mailSender.send(message);

	}
}
