package br.edu.utfpr.pb.pw25s.atividade1_2021.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(of = { "id" })
public class Compra implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false)
	private LocalDate data;

	@ManyToOne
	@JoinColumn(name = "usuario_id", referencedColumnName = "id")
	private Usuario usuario;

	@Column(name = "meio_pagamento", length = 1024)
	private String meioPagamento;

	@Column(name = "endereco_entrega", length = 1024)
	private String enderecoEntrega;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "id.compra")
	private List<CompraLivro> compraLivros;

	public double getValorTotal() {
		return compraLivros.stream().map(cp -> cp.getValor() * cp.getQuantidade())
				.collect(Collectors.summingDouble(Double::doubleValue));
	}

	public double getQtdCompraLivros() {

		double quantidade = (long) compraLivros.size();
		quantidade = quantidade - 1;
		return quantidade;
	}

}
