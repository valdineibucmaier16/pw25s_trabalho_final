package br.edu.utfpr.pb.pw25s.atividade1_2021.service;

import java.util.List;

import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Compra;
import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Usuario;

public interface CompraService extends CrudService<Compra, Long> {

	List<Compra> findByUsuario(Usuario usuario);
}
