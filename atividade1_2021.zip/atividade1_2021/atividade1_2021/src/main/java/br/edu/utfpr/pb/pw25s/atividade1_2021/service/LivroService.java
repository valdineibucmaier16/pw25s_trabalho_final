package br.edu.utfpr.pb.pw25s.atividade1_2021.service;

import java.util.List;

import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Livro;

public interface LivroService extends CrudService<Livro, Long> {

	List<Livro> findByGeneroDescricaoContains(String descricao);

}
