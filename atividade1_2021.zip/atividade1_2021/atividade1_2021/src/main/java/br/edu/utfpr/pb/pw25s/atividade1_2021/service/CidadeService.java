package br.edu.utfpr.pb.pw25s.atividade1_2021.service;

import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Cidade;

public interface CidadeService extends CrudService<Cidade, Long> {

}
