package br.edu.utfpr.pb.pw25s.atividade1_2021.dto;

import java.util.HashSet;
import javax.validation.constraints.NotBlank;
import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Endereco;
import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Usuario;

import lombok.Data;

@Data
public class RequisicaoNovoUsuario {

	@NotBlank(message = "Nome não deve estar em branco")
	private String nome;

	@NotBlank(message = "Username não deve estar em branco")
	private String username;

	@NotBlank(message = "Campo não deve estar em branco, senha deve possuir no mínimo seis caracteres")
	private String password;

	@NotBlank(message = "Campo não deve estar em branco")
	private String confirmacaoPassword;

	@NotBlank(message = "Email não deve estar em branco")
	private String email;

	@NotBlank(message = "Celular não deve estar em branco, deve possuir onze dígitos")
	private String celular;

	@NotBlank(message = "CEP não deve estar em branco")
	private String cep;

	@NotBlank(message = "Endereço não deve estar em branco")
	private String endereco;

	@NotBlank(message = "Número não deve estar em branco")
	private String numero;

	@NotBlank(message = "Bairro não deve estar em branco")
	private String bairro;

	private String complemento;

	@NotBlank(message = "Cidade não deve estar em branco, busque pelo CEP")
	private String cidade;

	@NotBlank(message = "Estado não deve estar em branco, busque pelo CEP")
	private String estado;

	public Boolean validaSenha() {

		if (this.password.length() >= 6) {
			if (this.password.equals(this.confirmacaoPassword)) {

				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}

	}

	public Usuario toUsuario() {

		Endereco endereco = new Endereco();
		endereco.setCep(cep);
		endereco.setEndereco(this.endereco);
		endereco.setNumero(numero);
		endereco.setBairro(bairro);
		endereco.setComplemento(complemento);
		endereco.setCidade(cidade);
		endereco.setEstado(estado);

		Usuario usuario = new Usuario();
		usuario.setNome(nome);
		usuario.setUsername(username);
		usuario.setPassword(password);
		usuario.setEmail(email);
		usuario.setCelular(celular);

		usuario.setEndereco(new HashSet<>());
		usuario.getEndereco().add(endereco);

		return usuario;
	}

}
