package br.edu.utfpr.pb.pw25s.atividade1_2021.controller;

import java.security.Principal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import br.edu.utfpr.pb.pw25s.atividade1_2021.dto.CompraDto;
import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Compra;
import br.edu.utfpr.pb.pw25s.atividade1_2021.model.CompraLivro;
import br.edu.utfpr.pb.pw25s.atividade1_2021.model.CompraLivroPK;
import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Usuario;
import br.edu.utfpr.pb.pw25s.atividade1_2021.service.CompraService;
import br.edu.utfpr.pb.pw25s.atividade1_2021.service.LivroService;

@Controller
@RequestMapping("compra-dto")
public class CompraControllerComDto {

	@Autowired
	private LivroService livroService;

	@Autowired
	private CompraService compraService;

	@GetMapping
	public String list(Model model, Principal principal) {

		Object obj = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		Usuario usuario = new Usuario();

		if (obj instanceof Usuario) {
			usuario = (Usuario) obj;
			model.addAttribute("compras", compraService.findByUsuario(usuario));
		}

		return "compra_list";
	}

	@PostMapping
	public ResponseEntity<?> save(@RequestBody @Valid CompraDto compraDto, BindingResult result, Model model,
			Principal principal) {
		try {
			if (result.hasErrors()) {
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}

			compraService.save(compraDtoToCompra(compraDto, principal));

			model.addAttribute("mensagem", "Compra salva com sucesso!");
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	public Compra compraDtoToCompra(CompraDto compraDto, Principal principal) {

		Object obj = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Usuario usuario = (Usuario) obj;

		Compra compra = new Compra();

		List<CompraLivro> compraLivros = new ArrayList<>();
		compraDto.getCompraLivros().forEach(cpDto -> {
			CompraLivroPK pk = new CompraLivroPK();
			pk.setCompra(compra);
			pk.setLivro(livroService.findOne(cpDto.getProdutoId()));

			CompraLivro cp = new CompraLivro();
			cp.setId(pk);
			cp.setQuantidade(cpDto.getQuantidade());
			cp.setValor(cpDto.getValor());
			compraLivros.add(cp);
		});

		compra.setData(LocalDate.now());

		compra.setUsuario(usuario);

		compra.setMeioPagamento(compraDto.getMeioPagamento());

		compra.setEnderecoEntrega(compraDto.getEnderecoEntrega());

		compra.setCompraLivros(compraLivros);

		return compra;
	}

}
