package br.edu.utfpr.pb.pw25s.atividade1_2021.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Compra;
import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Usuario;
import br.edu.utfpr.pb.pw25s.atividade1_2021.repository.CompraRepository;
import br.edu.utfpr.pb.pw25s.atividade1_2021.service.CompraService;

@Service
public class CompraServiceImpl extends CrudServiceImpl<Compra, Long> implements CompraService {

	@Autowired
	private CompraRepository compraRepository;

	@Override
	protected JpaRepository<Compra, Long> getRepository() {
		return compraRepository;
	}

	@Override
	public List<Compra> findByUsuario(Usuario usuario) {

		return compraRepository.findByUsuario(usuario);
	}

}
