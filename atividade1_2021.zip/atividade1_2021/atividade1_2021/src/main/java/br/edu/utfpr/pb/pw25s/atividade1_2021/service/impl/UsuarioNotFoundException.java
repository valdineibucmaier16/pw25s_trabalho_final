package br.edu.utfpr.pb.pw25s.atividade1_2021.service.impl;

@SuppressWarnings("serial")
public class UsuarioNotFoundException extends Exception {

	public UsuarioNotFoundException(String message) {
		super(message);

	}

}
