package br.edu.utfpr.pb.pw25s.atividade1_2021.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Usuario;
import br.edu.utfpr.pb.pw25s.atividade1_2021.repository.UsuarioRepository;
import br.edu.utfpr.pb.pw25s.atividade1_2021.service.UsuarioService;

@Service
public class UsuarioServiceImpl extends CrudServiceImpl<Usuario, Long> implements UsuarioService, UserDetailsService {

	@Autowired
	private UsuarioRepository usuarioRepository;

	@Override
	protected JpaRepository<Usuario, Long> getRepository() {
		return usuarioRepository;
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Usuario usuario = this.usuarioRepository.findByUsername(username);
		if (usuario == null) {
			throw new UsernameNotFoundException("Usuário não encontrado");
		}
		return usuario;
	}

	public void updateResetPasswordToken(String token, String email) throws UsuarioNotFoundException {
		Usuario usuario = usuarioRepository.findByEmail(email);
		if (usuario != null) {
			usuario.setResetPasswordToken(token);
			usuarioRepository.save(usuario);
		} else {
			throw new UsuarioNotFoundException("Não foi possível localizar nenhum usuário com email " + email);
		}

	}

	public Usuario get(String resetPasswordToken) {

		return usuarioRepository.findByResetPasswordToken(resetPasswordToken);
	}

	public void updatePassword(Usuario usuario, String newPassword) {

		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword = passwordEncoder.encode(newPassword);
		usuario.setPassword(encodedPassword);
		usuario.setResetPasswordToken(null);

		usuarioRepository.save(usuario);

	}

}
