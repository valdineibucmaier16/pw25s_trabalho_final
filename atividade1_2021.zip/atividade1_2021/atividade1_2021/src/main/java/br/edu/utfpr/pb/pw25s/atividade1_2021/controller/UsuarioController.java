package br.edu.utfpr.pb.pw25s.atividade1_2021.controller;

import java.util.HashSet;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import br.edu.utfpr.pb.pw25s.atividade1_2021.dto.RequisicaoNovoUsuario;
import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Usuario;
import br.edu.utfpr.pb.pw25s.atividade1_2021.repository.PermissaoRepository;
import br.edu.utfpr.pb.pw25s.atividade1_2021.repository.UsuarioRepository;

@Controller
public class UsuarioController {

	@Autowired
	private UsuarioRepository repository;

	@Autowired
	private PermissaoRepository permissaoRepository;

	/*
	 * @GetMapping(value = {"usuario"}) public String form(Model model) {
	 * model.addAttribute("usuario", new Usuario()); return "form_usuario"; }
	 */

	@GetMapping(value = { "usuario" })
	public String form(RequisicaoNovoUsuario requisicao) {

		return "form_usuario";
	}

	/*
	 * @PostMapping(value= {"usuario"}) public String novo(@Valid Usuario usuario,
	 * BindingResult result, Model model, RedirectAttributes attributes) {
	 * 
	 * 
	 * if(result.hasErrors()) { return "form_usuario"; }
	 * 
	 * 
	 * String password = usuario.getPassword(); BCryptPasswordEncoder
	 * passwordEncoder = new BCryptPasswordEncoder();
	 * usuario.setPassword(passwordEncoder.encode(password));
	 * 
	 * 
	 * usuario.setPermissoes(new HashSet<>());
	 * usuario.getPermissoes().add(permissaoRepository.getById(2L));
	 * repository.save(usuario); return "login"; }
	 */

	@PostMapping(value = { "usuario" })
	public String novo(@Valid RequisicaoNovoUsuario requisicao, BindingResult result, RedirectAttributes attributes,
			Model model) {

		if (result.hasErrors()) {
			return "form_usuario";
		}

		String emailUsuario = requisicao.getEmail();

		if (repository.findByEmail(emailUsuario) != null) {
			model.addAttribute("erroEmail", "Email já existe para outro usuário");
			return "form_usuario";
		}

		if (requisicao.validaSenha()) {

			Usuario usuario = requisicao.toUsuario();
			String password = usuario.getPassword();
			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			usuario.setPassword(passwordEncoder.encode(password));

			usuario.setPermissoes(new HashSet<>());
			usuario.getPermissoes().add(permissaoRepository.getById(2L));
			repository.save(usuario);
			attributes.addFlashAttribute("sucesso", "Usuário cadastrado com sucesso!");
			return "redirect:/login";

		} else {
			return "form_usuario";
		}

	}
}
