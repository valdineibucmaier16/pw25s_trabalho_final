package br.edu.utfpr.pb.pw25s.atividade1_2021.dto;

import lombok.Data;

@Data
public class CompraLivroDto {
	private Long produtoId;

	private Integer quantidade;

	private Double valor;
}
