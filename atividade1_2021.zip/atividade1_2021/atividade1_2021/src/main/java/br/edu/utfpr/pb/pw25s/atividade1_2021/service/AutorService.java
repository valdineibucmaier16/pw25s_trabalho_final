package br.edu.utfpr.pb.pw25s.atividade1_2021.service;

import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Autor;

public interface AutorService extends CrudService<Autor, Long> {

}
