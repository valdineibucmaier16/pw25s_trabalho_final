package br.edu.utfpr.pb.pw25s.atividade1_2021.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Compra;

import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Usuario;

public interface CompraRepository extends JpaRepository<Compra, Long> {

	List<Compra> findByUsuario(Usuario usuario);
}
