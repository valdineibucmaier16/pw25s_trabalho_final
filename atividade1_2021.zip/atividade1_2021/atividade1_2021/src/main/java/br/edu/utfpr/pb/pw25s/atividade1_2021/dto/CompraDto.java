package br.edu.utfpr.pb.pw25s.atividade1_2021.dto;

import java.util.List;

import lombok.Data;

@Data
public class CompraDto {

	private List<CompraLivroDto> compraLivros;

	private String meioPagamento;

	private String enderecoEntrega;

}