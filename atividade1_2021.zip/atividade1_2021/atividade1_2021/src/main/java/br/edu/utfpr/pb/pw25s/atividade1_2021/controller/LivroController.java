package br.edu.utfpr.pb.pw25s.atividade1_2021.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Genero;
import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Livro;
import br.edu.utfpr.pb.pw25s.atividade1_2021.service.GeneroService;
import br.edu.utfpr.pb.pw25s.atividade1_2021.service.LivroService;

@Controller
@RequestMapping("livros")
public class LivroController {

	@Autowired
	private LivroService livroService;
	@Autowired
	private GeneroService generoService;

	/*
	 * @Autowired private LivroRepository repository;
	 * 
	 * @Autowired private GeneroRepository generoRepository;
	 */

	@GetMapping
	public String listaLivros(Model model) {

		List<Livro> livros = livroService.findAll();
		model.addAttribute("livros", livros);
		List<Genero> generos = generoService.findAll();
		model.addAttribute("generos", generos);
		String msg = "Todos os livros!";
		model.addAttribute("mensagemLivros", msg);
		return "list";
	}

	@GetMapping(value = { "todos" })
	public String listaLivrosTodos(Model model) {
		List<Livro> livros = livroService.findAll();
		model.addAttribute("livros", livros);
		List<Genero> generos = generoService.findAll();
		model.addAttribute("generos", generos);
		String msg = "Todos os livros!";
		model.addAttribute("mensagemLivros", msg);
		return "list";
	}

	@GetMapping(value = { "java", "Java" })
	public String listaLivrosJava(Model model) {
		List<Livro> livrosJava = livroService.findByGeneroDescricaoContains("Java");
		model.addAttribute("livros", livrosJava);
		List<Genero> generos = generoService.findAll();
		model.addAttribute("generos", generos);
		String msg = "Livros de Java!";
		model.addAttribute("mensagemLivros", msg);
		return "list";
	}

	@GetMapping(value = { "c#", "C#", "cSharp", "CSharp", "csharp" })
	public String listaLivrosCSharp(Model model) {
		List<Livro> livrosCSharp = livroService.findByGeneroDescricaoContains("C#");
		model.addAttribute("livros", livrosCSharp);
		List<Genero> generos = generoService.findAll();
		model.addAttribute("generos", generos);
		String msg = "Livros de C#!";
		model.addAttribute("mensagemLivros", msg);
		return "list";
	}

	@GetMapping(value = { "kotlin", "Kotlin" })
	public String listaLivrosKotlin(Model model) {
		List<Livro> livrosKotlin = livroService.findByGeneroDescricaoContains("Kotlin");
		model.addAttribute("livros", livrosKotlin);
		List<Genero> generos = generoService.findAll();
		model.addAttribute("generos", generos);
		String msg = "Livros de Kotlin!";
		model.addAttribute("mensagemLivros", msg);
		return "list";
	}

	@GetMapping(value = { "javascript", "Javascript" })
	public String listaLivrosJavascript(Model model) {
		List<Livro> livrosJavascript = livroService.findByGeneroDescricaoContains("Javascript");
		model.addAttribute("livros", livrosJavascript);
		List<Genero> generos = generoService.findAll();
		model.addAttribute("generos", generos);
		String msg = "Livros de Javascript!";
		model.addAttribute("mensagemLivros", msg);
		return "list";
	}

	/*
	 * @GetMapping(value = {"Java/{id}", "java/{id}"}) public String
	 * detail(@PathVariable("id") Long id, Model model) { List<Genero> generos =
	 * generoService.findAll(); model.addAttribute("generos", generos); //Livro
	 * livro = livroService.getOne(id); Livro livro = livroService.findOne(id);
	 * model.addAttribute("livros", livro); return "livros/java/detail"; }
	 */

	@GetMapping(value = { "{id}" })
	public String detail(@PathVariable("id") Long id, Model model) {
		List<Genero> generos = generoService.findAll();
		model.addAttribute("generos", generos);
		Livro livro = livroService.findOne(id);
		model.addAttribute("livros", livro);
		return "detail";
	}
}
