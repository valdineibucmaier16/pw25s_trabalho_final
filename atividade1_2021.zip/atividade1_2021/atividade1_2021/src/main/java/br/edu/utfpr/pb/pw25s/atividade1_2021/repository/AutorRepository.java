package br.edu.utfpr.pb.pw25s.atividade1_2021.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.edu.utfpr.pb.pw25s.atividade1_2021.model.Autor;

public interface AutorRepository extends JpaRepository<Autor, Long> {

}
