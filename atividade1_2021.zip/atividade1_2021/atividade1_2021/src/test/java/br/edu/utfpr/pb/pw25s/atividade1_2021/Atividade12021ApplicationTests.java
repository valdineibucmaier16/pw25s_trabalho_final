package br.edu.utfpr.pb.pw25s.atividade1_2021;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atividade12021ApplicationTests {

	@Test
	void contextLoads() {
	}

}
